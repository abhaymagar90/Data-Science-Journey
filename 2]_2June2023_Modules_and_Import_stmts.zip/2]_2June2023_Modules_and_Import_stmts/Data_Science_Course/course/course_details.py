import os, sys
from os.path import dirname, join, abspath

sys.path.insert(0, abspath(join(dirname(__file__), '..')))


# from payment import payment_details

# payment_details.payment()      -> error


def course():
    print("This is my course file")



# payment_details.payment() 