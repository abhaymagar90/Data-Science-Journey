from flask import Flask  
from flask import request
  
app = Flask(__name__)  
 
@app.route('/')   
def home():  
    return "hello world";  
  
@app.route('/home1')   
def home1():  
    return "hello world 1";  
  
@app.route('/home2')   
def home2():  
    return "hello world 2";  
  
@app.route("/test")
def test():
    a = 5 + 6
    return " This is my addition of 5 and 6 -> {}".format(a)

@app.route("/input")
def input_url():
    data = request.args.get("x")
    return f" This is input from user at cilent side : {data}"



if __name__ =='__main__':  
    app.run(host = "0.0.0.0")  